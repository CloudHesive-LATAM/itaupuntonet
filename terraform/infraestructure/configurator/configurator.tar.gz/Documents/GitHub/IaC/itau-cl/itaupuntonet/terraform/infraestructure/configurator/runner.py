import sys

sys.exit('key1=value,key2=value2,key3=value3')
